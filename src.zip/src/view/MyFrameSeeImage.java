package view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.io.File;

import javax.swing.*;

import util.ShapeDetector;

public class MyFrameSeeImage extends JFrame {
    private final String title = "Football - Hors Jeu";
    private MyPanelPicture panelPicture;
    private JPanel panelChosingSides;

    public MyFrameSeeImage() {
    }

    public MyFrameSeeImage(File f) {
        setTitle(title);

        setLayout(new BorderLayout());
        setSize(500, 1000);

        // Initialize panelChosingSides
        panelChosingSides = new JPanel(); // Add this line

        setMyPanelPicture(f);

        panelChosingSides.setLayout(new FlowLayout()); // Now this will not throw a NullPointerException

        JButton sidesUpButton = new JButton("Put Red Team Up");
        JButton sidesDownButton = new JButton("Put Red Team Down");

        panelChosingSides.add(sidesUpButton);
        panelChosingSides.add(sidesDownButton);
        
        //MyButtonUploadImage uploadButton = new MyButtonUploadImage(this);

        add(getMyPanelPicture(), BorderLayout.CENTER);
        //add(uploadButton, BorderLayout.SOUTH);
        add(panelChosingSides, BorderLayout.NORTH); // Add the panelChosingSides to the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void setMyPanelPicture(File f) {
        panelPicture = new MyPanelPicture(f);
    }

    public MyPanelPicture getMyPanelPicture() {
        return panelPicture;
    }
}
