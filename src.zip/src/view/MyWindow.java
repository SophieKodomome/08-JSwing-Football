package view;

import javax.swing.*;

public class MyWindow extends JFrame {


    public MyWindow(){
        new MyFrameUploadImage();
    }

}
